<?php

use Illuminate\Database\Eloquent\Model as Eloquent;

class Village extends Eloquent {
	
	protected $table = 't_village';
}
